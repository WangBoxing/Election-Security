<meta charset="UTF-8">
<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

$user=$_POST["user"];
$pass=$_POST["pass"];

$conn=mysqli_connect("localhost","root","","vote_db");


if($_SERVER["REQUEST_METHOD"] == "POST"){
    $flag=1;
?>

<?php
    
    $sql="SELECT * from users where user = '$user' and pass = '$pass';";
    $query=mysqli_query($conn,$sql);
    $result = $conn->query($sql);
    
    if($row = $result->fetch_assoc()){
        $_SESSION["user"]=$user;
        $_SESSION["pass"]=$pass;
?>
    <script>
    alert("选民登录成功!");
    window.location.href="homePage.php";
    </script>
<?php
    }else if(mysqli_num_rows($query) == 0 && $flag == 1 && $pass != $row['pass']){
?>
 <script>alert("用户名不存在，请进行注册");
  window.location.href="demo.php";
</script>
<?php
    }else if($pass != $row["pass"] && $flag == 1){
?>
<script>alert("密码错误，请重新输入");
 window.location.href="demo.php";
</script>
<?php
    }
}
?>