<meta charset="UTF-8">
<?php
if (!session_id())
session_start();
error_reporting(0);

$user=$_SESSION["user"];
$cname=$_POST["cname"];

$conn=mysqli_connect("localhost","root","","vote_db");
$sql1="SELECT * from candidate where name = '$cname';";
$query=mysqli_query($conn,$sql1);
$row=mysqli_fetch_array($query);
$number=$row["vnumber"];

$conn=mysqli_connect("localhost","root","","vote_db");
$sql="UPDATE users SET cname = '$cname' where user= '$user';";

if(mysqli_query($conn,$sql)){
    $number=$number+1;
    $sql2="UPDATE candidate SET vnumber = $number where name = '$cname';";
    mysqli_query($conn,$sql2); 
?>
    <script>
    alert("投票成功!");
    window.location.href="homePage.php";
    </script>
<?php
}
?>

