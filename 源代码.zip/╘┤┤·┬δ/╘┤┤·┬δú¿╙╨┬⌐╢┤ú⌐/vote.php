<meta charset="UTF-8">
<?php
if (!session_id())
session_start();
error_reporting(0);

$user=$_SESSION["user"];
$cname=$_POST["cname"];

$conn=mysqli_connect("localhost","root","","vote_db");
$sql1="SELECT * from candidate where name = '$cname';";
$query=mysqli_query($conn,$sql1);
$row=mysqli_fetch_array($query);
$number=$row["vnumber"];

$conn=mysqli_connect("localhost","root","","vote_db");
$sql = $conn->prepare("UPDATE users set cname= ? WHERE user = ?");
$sql->bind_param("ss", $cname, $user);

if ($sql->execute()) {
    echo "<script>alert('错误！');
    window.history.back(-1);
    </script>";
    
} else {
    $number=$number+1;
    $sql2="UPDATE candidate SET vnumber = $number where name = '$cname';";
    mysqli_query($conn,$sql2);
    echo "<script>alert('投票成功！');
    </script>";
?>
<script>
    window.location.href="homePage.php";
</script>
<?php
}
$sql->close();
?>


