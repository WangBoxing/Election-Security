<?php
$servername="localhost";
$username="root";
$password="";
$dbname="vote_db";


// 创建数据库
$conn=mysqli_connect($servername,$username,$password);
$sql = " CREATE DATABASE vote_db";
mysqli_query($conn,$sql);


// 创建选民表
$conn=mysqli_connect($servername,$username,$password,$dbname);
$sql1="CREATE table users(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, /**用户编号 */
user VARCHAR(30) NOT NULL, /**用户名 */
pass VARCHAR(30) NOT NULL, /**用户密码 */
cname VARCHAR(30)
)";
mysqli_query($conn, $sql1);

$insert="INSERT into users (id,user,pass,cname) VALUES";

for($i=1;$i<20;$i++){
    $id=$i;
    $u="user".$i;
    $p="user".$i;

    $insert1="('$id','$u','$p','nobody');";
    $insert2=$insert .$insert1;
    mysqli_query($conn,$insert2);
}


//创建候选人表
$conn=mysqli_connect($servername,$username,$password,$dbname);
$sql2="CREATE table candidate(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, /**用户编号 */
name VARCHAR(30) NOT NULL, /**用户名 */
vnumber int(6) NOT NULL
)";
mysqli_query($conn, $sql2);

$insert="INSERT into users (id,name,vnumber) VALUES";

for($i=1;$i<6;$i++){
    $id=$i;
    $name="candidate".$i;
    $vnumber=0;

    $insert1="('$id','$name','$vnumber');";
    $insert2=$insert .$insert1;
    mysqli_query($conn,$insert2);
}


?>