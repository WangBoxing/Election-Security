<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <link rel="stylesheet" href="c/css/bootstrap.css">
    <link rel="stylesheet" href="c/login/login.css">
    <link rel="stylesheet" href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.css">
	
    <script src="j/js/jquery.js"></script>
    <script src="j/js/bootstrap.js"></script>
	
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <div>
        <div class="be-content pren">

            <div class="ioc_text">
                <img src="i/login/logo.png" alt="">
                <span>投票系统</span>
            </div>

            <div>
                <form action="login.php" method="post" id="form">
                    <div class="br-content">

                         <div class="input-group mb-4 bootint">
                             <div class="input-group-prepend">
                                 <span class="input-group-text"><i class="fa fa-user"></i></span>
                             </div>
                             <input type="text" class="form-control" placeholder="Username" name="user">
                         </div>

                         <div class="input-group mb-4 bootint">
                             <div class="input-group-prepend">
                                 <span class="input-group-text"><i class="fa fa-unlock-alt"></i></span>
                             </div>
                             <input type="password" class="form-control" placeholder="Your Password" name="pass">
                         </div>

                        <div class="br-text">
                            <p>
                                <span>忘记密码?</span>
                                <a href="">找回</a>
                            </p>
                        </div>
                        <div style="padding-top: 10px">
                            <input type="submit" class="btn" value="登录">
                        </div>
                        <div class="be-con">
                            <span>Copyright © 2022 <a href="">投票系统登陆</a></span>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
	
</body>
</html>