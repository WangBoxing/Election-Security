<meta charset="UTF-8">
<?php
if (!session_id())
session_start();

    unset($_SESSION['user']);
    unset($_SESSION['pass']);
?>
<script>
    alert("退出登录成功");
    window.location.href="demo.php";
</script>