<meta charset="UTF-8">
<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

$user=$_POST["user"];
$pass=$_POST["pass"];

$conn=mysqli_connect("localhost","root","","vote_db");


if($_SERVER["REQUEST_METHOD"] == "POST"){

    $sql = $conn->prepare("SELECT user FROM users WHERE user = ? and pass = ?");
    $sql->bind_param("ss", $user, $pass);
    $sql->execute();
    $sql->bind_result($user);
    $sql->fetch();
    $sql->close();

    if ($user == NULL) {
        echo "<script>alert('错误');</script>";
?>
<script>
    window.location.href="demo.php";
</script>
<?php
    }else{
        $_SESSION['user'] = $user;
        $_SESSION['pass']=$pass;
?>
<script>
    alert("登录成功！");
    window.location.href="homePage.php";
</script>
<?php
        exit();
    }
}
?>