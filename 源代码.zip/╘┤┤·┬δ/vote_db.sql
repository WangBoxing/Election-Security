-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2022 年 9 月 20 日 11:19
-- 服务器版本: 5.6.12-log
-- PHP 版本: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `vote_db`
--
CREATE DATABASE IF NOT EXISTS `vote_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `vote_db`;

-- --------------------------------------------------------

--
-- 表的结构 `candidate`
--

CREATE TABLE IF NOT EXISTS `candidate` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `vnumber` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `candidate`
--

INSERT INTO `candidate` (`id`, `name`, `vnumber`) VALUES
(1, 'cadidate1', 2),
(2, 'cadidate2', 2),
(3, 'cadidate3', 2),
(4, 'cadidate4', 0),
(5, 'cadidate5', 0),
(6, 'cadidate6', 10),
(7, 'cadidate7', 3),
(8, 'cadidate8', 3);

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `cname` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `user`, `pass`, `cname`) VALUES
(1, 'user1', 'user1', 'cadidate1'),
(2, 'user2', 'user2', 'nobody'),
(3, 'user3', 'user3', 'cadidate3'),
(4, 'user4', 'user4', 'nobody'),
(5, 'user5', 'user5', 'nobody'),
(6, 'user6', 'user6', 'nobody'),
(7, 'user7', 'user7', 'nobody'),
(8, 'user8', 'user8', 'cadidate8'),
(9, 'user9', 'user9', 'nobody'),
(10, 'user10', 'user10', 'nobody'),
(11, 'user11', 'user11', 'nobody'),
(12, 'user12', 'user12', 'nobody'),
(13, 'user13', 'user13', 'nobody'),
(14, 'user14', 'user14', 'nobody'),
(15, 'user15', 'user15', 'nobody'),
(16, 'user16', 'user16', 'nobody'),
(17, 'user17', 'user17', 'nobody'),
(18, 'user18', 'user18', 'nobody'),
(19, 'user19', 'user19', 'nobody');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
